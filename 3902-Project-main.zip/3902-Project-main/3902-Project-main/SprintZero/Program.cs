﻿using var game = new SprintZero.Game1();
game.Run();

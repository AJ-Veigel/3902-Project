﻿
using Microsoft.Xna.Framework;
namespace SprintZero.Controllers
{
   
    public interface IController
    {
 
        void Update(GameTime gameTime);
    }
}
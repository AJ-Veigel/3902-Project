﻿
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using MonoGameLibrary.Graphics;
using SpriteZero.Sprites;

public class animatedButNonMoving : ISprite
{
    private AnimatedSprite sprite;
    public Vector2 location{get;set;}

    public animatedButNonMoving(AnimatedSprite animated)
    {
      
        sprite = animated;
       sprite.Scale = new Vector2(4f);
 
        location = new Vector2(0,0);
    }
    public void Update(GameTime gameTime)
    {
        sprite.Update(gameTime);
    }
    public void Draw(SpriteBatch spriteBatch)
    {
    
        sprite.Draw(spriteBatch, location);
    }
}
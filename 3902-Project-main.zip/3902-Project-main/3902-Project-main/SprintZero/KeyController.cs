﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using SprintZero;
using SprintZero.Controllers;

public class KeyController : IController
{
    private Game1 game;
    private KeyboardState previousState;

    public KeyController(Game1 game)
    {
        this.game = game;
        previousState = Keyboard.GetState();
    } 
    public void Update(GameTime gameTime)
    {
    KeyboardState current = Keyboard.GetState();
    if ((current.IsKeyDown(Keys.Q)) && previousState.IsKeyUp(Keys.Q))
        {
            game.Exit();
        }
    if ((current.IsKeyDown(Keys.T) && previousState.IsKeyUp(Keys.T)))
        {
            game.PreviousBlock();
        }
    if ((current.IsKeyDown(Keys.Y) && previousState.IsKeyUp(Keys.Y)))
        {
            game.NextBlock();
        }
    if ((current.IsKeyDown(Keys.U) && previousState.IsKeyUp(Keys.U)))
        {
            game.PreviousItem();
        }
    if ((current.IsKeyDown(Keys.I) && previousState.IsKeyUp(Keys.I)))
        {
            game.NextItem();
        }
        if((current.IsKeyDown(Keys.D1) && previousState.IsKeyUp(Keys.D1)) || (current.IsKeyDown(Keys.NumPad1) && previousState.IsKeyUp(Keys.NumPad1)))
        {
            int smallMario = 0;
            game.SetMario(smallMario);
        }
        if((current.IsKeyDown(Keys.D2) && previousState.IsKeyUp(Keys.D2)) || (current.IsKeyDown(Keys.NumPad2) && previousState.IsKeyUp(Keys.NumPad2)))
        {
            int bigMario = 1;
            game.SetMario(bigMario);
        }
        previousState = current;
    }
}
